package com.example.a3track.Util;

public enum RequestState {
    LOADING,
    SUCCESS,
    INVALID_CREDENTIALS,
    UNKNOWN_ERROR
}
