package com.example.a3track.model

data class Department(var ID: Int,
                      var name: String
)
