package com.example.a3track.model

enum class LoginResult {
    LOADING,
    SUCCESS,
    INVALID_CREDENTIALS,
    UNKNOWN_ERROR
}