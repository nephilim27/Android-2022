package com.example.a3track.models

import com.example.a3track.model.Department

data class DepartmentModel(var ID: Int,
                           var name: String)
